<?php

declare(strict_types=1);

namespace RLTSquare\EmailSender\Controller\Index;

use Magento\Backend\App\Action\Context;
use Magento\Framework\App\ActionInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\App\RouterInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\MailException;
use Magento\Framework\View\Result\PageFactory;
use RLTSquare\EmailSender\Logger\Logger;
use RLTSquare\EmailSender\Model\EmailSend;

/**
 *package for sending email and logging in logs
 */
class Routes implements RouterInterface
{
    /**
     * @var Logger
     */
    protected Logger $logger;
    /**
     * @var Context
     */
    protected Context $context;
    /**
     * @var EmailSend
     */
    protected EmailSend $emailSend;
    /**
     * @var PageFactory
     */
    protected PageFactory $pageFactory;


    /**
     * @param Logger $logger
     * @param EmailSend $emailSend
     */
    public function __construct(
        Logger      $logger,
        EmailSend   $emailSend,
    ) {
        $this->logger = $logger;
        $this->emailSend = $emailSend;
    }

    /**
     * @param RequestInterface $request
     * @return ActionInterface
     */
    public function match(RequestInterface $request): ActionInterface
    {
        $this->logger->info('Email has been sent');
        try {
            $this->emailSend->execute();
            echo "TEST";
        } catch (MailException|LocalizedException $e) {
            echo $e->getMessage();
        }
        exit();
    }
}
