<?php

declare(strict_types=1);

namespace RLTSquare\EmailSender\Logger;

class Logger extends \Monolog\Logger
{

}
